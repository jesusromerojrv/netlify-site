import { BrowserRouter, Route, Routes } from "react-router-dom";
import Inicio from "./components/Inicio";
import Header from "./components/Header";
import Footer from "./components/Footer";
import Options from "./components/OptionsApp";
import React, { useEffect, useState } from "react";
import { useTheme, ThemeProvider, createTheme } from "@mui/material/styles";

import Brightness4Icon from "@mui/icons-material/Brightness4";
import Brightness7Icon from "@mui/icons-material/Brightness7";
import IconButton from "@mui/material/IconButton";
import Container from "@mui/material/Container";
import Box from "@mui/material/Box";

const ColorModeContext = React.createContext({
  toggleColorMode: () => {},
});

function App() {
  const theme = useTheme();
  const colorMode = React.useContext(ColorModeContext);
  const [darkState, setDarkState] = useState(true);

  useEffect(() => {
    const existingPreference = localStorage.getItem("darkState");
    if (existingPreference === "dark") {
      //condición para cambiar el modo de color de la interfaz a color negro
      colorMode.toggleColorMode();
      setItemLS();
    }
  }, []);

  //constante para manejar el modo de color de la interfaz (negro o blanco)
  const setItemLS = () => {
    setDarkState(!darkState);
    if (darkState) {
      localStorage.setItem("darkState", "dark");
    } else {
      localStorage.setItem("darkState", "light");
    }
  };

  return (
    <>
      {" "}
      <Container>
        <Box sx={{ mx: "auto", width: 55 }}>
          <IconButton //formato de icono del botón
            sx={{ ml: 1 }}
            onClick={() => {
              colorMode.toggleColorMode();
              setItemLS();
            }}
            color="inherit"
            align="center"
          >
            {theme.palette.mode === "dark" ? (
              <Brightness7Icon />
            ) : (
              <Brightness4Icon />
            )}
          </IconButton>
        </Box>
      </Container>
      <Header />
      <Inicio />
      <Footer />
    </>
  );
}

//función para alternar el modo de color de la interfaz
function ToggleColorMode() {
  const [mode, setMode] = React.useState("light");
  const colorMode = React.useMemo(
    () => ({
      toggleColorMode: () => {
        setMode((prevMode) => (prevMode === "light" ? "dark" : "light"));
      },
    }),
    []
  );

  //constante para poder usar el modo y paleta de color
  const theme = React.useMemo(
    () =>
      createTheme({
        palette: {
          mode,
        },
      }),
    [mode]
  );

  return (
    <ColorModeContext.Provider value={colorMode}>
      <ThemeProvider theme={theme}>
        <App />
      </ThemeProvider>
    </ColorModeContext.Provider>
  );
}

export default ToggleColorMode;
