import { Container } from "@mui/material";
import Typography from "@mui/material/Typography";
import Image from "react-bootstrap/Image";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Button from "react-bootstrap/Button";
import { Box } from "@mui/material";
import { useTranslation } from "react-i18next";

export default function About() {
  const [t] = useTranslation("global");
  return (
    <>
      <Box
        sx={{
          backgroundColor: "#000",
          padding: { lg: "2%", sm: "5%", xs: "5%" },
        }}
        id="sobre_me"
      >
        <Container
          maxWidth={false}
          sx={{
            color: "#fff",
          }}
        >
          <Box
            sx={{
              paddingRight: { lg: "10%", sm: "1%" },
              paddingLeft: { lg: "10%", sm: "1%" },
            }}
          >
            <Row>
              <Col xxl={5} style={{ textAlign: "center" }}>
                <Box>
                  <Image
                    className="responsive3"
                    style={{
                      textAlign: "center",
                      backgroundColor: "white",
                      padding: "2%",
                    }}
                    src="https://us.123rf.com/450wm/dotshock/dotshock1602/dotshock160200726/52352665-negocio-de-inicio-desarrollador-de-software-trabajando-en-equipo-en-la-oficina-moderna.jpg?ver=6"
                  />
                </Box>
              </Col>
              <Col xxl={7} style={{ textAlign: "justify" }}>
                <Typography variant="h6" gutterBottom>
                  {t("about.title")}
                </Typography>
                <Typography variant="body1" gutterBottom>
                  {t("about.description")}
                  <br />
                  <br />
                </Typography>
                <Button
                  variant="outline-light"
                  style={{ background: "#efb810" }}
                  onClick={() => window.open("/CV Resumen Jesus Romero.pdf")}
                >
                  {t("about.button")}
                </Button>
              </Col>
            </Row>
          </Box>
        </Container>
      </Box>
    </>
  );
}
