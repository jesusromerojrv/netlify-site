import { Body } from "./Body";

export default function Inicio() {
  return (
    <>
      <Body />
    </>
  );
}
