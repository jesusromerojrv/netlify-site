const LightTheme = {
    about: {
        bgc: "#000",
        color: "#fff",
        bgcImg: "#fff",
        bgcButton: "#efb810"
    }
}
const Themes = {
    light: LightTheme
}

export default Themes