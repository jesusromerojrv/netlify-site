import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import IconButton from "@mui/material/IconButton";
import MenuIcon from "@mui/icons-material/Menu";
import OverlayTrigger from "react-bootstrap/OverlayTrigger";
import Popover from "react-bootstrap/Popover";
import Home from "@mui/icons-material/HomeOutlined";
import Drawer from "@mui/material/Drawer";
import NavListDrawer from "./NavListDrawer";
import ScrollToColor from "./ScrollToColor";
import LaptopIcon from "@mui/icons-material/Laptop";
import { useState } from "react";

export default function Header() {
  const [open, setOpen] = useState(false);

  return (
    <Box sx={{ flexGrow: 1, }}>
      <ScrollToColor>
        <AppBar color="transparent" elevation={0}>
          <Toolbar>
            <IconButton
              size="large"
              edge="start"
              color="inherit"
              aria-label="menu"
              sx={{ mr: 4, display: {xs: "block", sm: "none"} }}
              onClick={() => setOpen(true)}
            >
              <LaptopIcon />
            </IconButton>
            <IconButton
              size="large"
              edge="start"
              color="inherit"
              aria-label="menu"
              sx={{ mr: 4, display: {xs: "none", sm: "block"} }}
            >
              <LaptopIcon />
            </IconButton>
            <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
              ¡¡Bienvenid@s!!
            </Typography>
            <Box sx={{display: {xs: "none", sm: "block"}}}>
              <Button href="/#banner" color="inherit">
                Inicio
              </Button>
              <Button href="/#sobre_me" color="inherit">
                Sobre Mi
              </Button>
              <Button href="/#portafolio" color="inherit">
                Potafolio
              </Button>
              <Button href="/#skills" color="inherit">
                Habilidades
              </Button>
              <Button href="/#contenedorContacto" color="inherit">
                Contacto
              </Button>
            </Box>
          </Toolbar>
        </AppBar>
      </ScrollToColor>
      <Drawer open={open} anchor="left" onClose={() => setOpen(false)}>
        <NavListDrawer />
      </Drawer>
    </Box>
  );
}
