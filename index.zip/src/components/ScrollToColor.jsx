import React from "react";
import useScrollTrigger from '@mui/material/useScrollTrigger';

const ScrollHandler = props => {
  const trigger = useScrollTrigger({
    disableHysteresis: true,
    threshold: 0,
    target: props.window ? window() : undefined
  });

  return React.cloneElement(props.children, {
    style: {
      backgroundColor: trigger ? "#000" : "transparent",
      color: trigger ? "#fff" : "#FFF",
      transition: trigger ? "0.3s" : "0.5s",
    }
  });
};

const ScrollToColor01 = props => {
  return <ScrollHandler {...props}>{props.children}</ScrollHandler>;
};

export default ScrollToColor01;
