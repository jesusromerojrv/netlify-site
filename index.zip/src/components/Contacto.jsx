import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import Button from "react-bootstrap/Button";

export default function Contacto() {
  return (
    <Box
      component="form"
      noValidate
      autoComplete="off"
      className="contCards"
      sx={{ padding: "10%", paddingTop: { lg: "2%", sm: "5%", xs: "5%" }, textAlign: "center" }}
      id="contenedorContacto"
    >
      <Typography variant="h6" gutterBottom color={"#efb810"}>
        <b>CONTACTO</b>
      </Typography>
      <hr />
      <br />
      <br />
      <TextField
        fullWidth
        label="Correo Electronico"
        id="fullWidth"
        sx={{ backgroundColor: "#fff" }}
      />
      <br />
      <br />
      <TextField
        fullWidth
        id="fullWidth"
        label="Escribe tu mensaje"
        multiline
        rows={10}
        sx={{ backgroundColor: "#fff" }}
      />
      <br />
      <br />
      <Button
        variant="outline-light"
        style={{ width: "100%", background: "#efb810" }}
      >
        Enviar
      </Button>
    </Box>
  );
}
